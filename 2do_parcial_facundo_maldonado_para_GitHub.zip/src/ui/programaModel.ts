import {useSyncExternalStore} from 'react';
import {agendaRepository as repo} from '../data/AgendaRepository';
import {ajuste,Charla} from '../data/archivo';

type Estado = {charlas: Charla[]; cargando: boolean; aviso: string; descargado: boolean};
let estado: Estado = {charlas: [], cargando: false, aviso: '', descargado: false};
const observadores = new Set<() => void>();
let enCurso = false;
let pendiente = false;
let inicioAutomatico = false;
function publicar(cambios: Partial<Estado>) {
  estado = {...estado,...cambios};
  observadores.forEach(fn => fn());
}
function suscribir(fn: () => void) {
  observadores.add(fn);
  return () => { observadores.delete(fn); };
}
export function usePrograma() {
  return useSyncExternalStore(suscribir, () => estado);
}
export async function iniciarPrograma() {
  if (inicioAutomatico) return;
  inicioAutomatico = true;
  await recargar();
}
export async function recargar() {
  if (enCurso) { pendiente = true; return; }
  enCurso = true;
  publicar({cargando: true, aviso: ''});
  try {
    do {
      pendiente = false;
      try {
        const [guardadas, valida] = await Promise.all([
          repo.listar(), ajuste('programa_descargado', 'no'),
        ]);
        publicar({charlas: guardadas, descargado: valida === 'si'});
        await repo.sincronizar();
        publicar({charlas: await repo.listar(), descargado: true, aviso: ''});
      } catch (error) {
        console.warn('No se pudo actualizar el programa', error);
        const [guardadas, valida] = await Promise.all([
          repo.listar(), ajuste('programa_descargado', 'no'),
        ]);
        const descargado = valida === 'si';
        publicar({charlas: guardadas, descargado,
          aviso: descargado ? 'Sin señal: usando datos guardados.' : 'No se pudo consultar el programa. Reintentá.'});
      }
    } while (pendiente);
  } finally {
    enCurso = false;
    publicar({cargando: false});
  }
}
export async function marcar(id: string) {
  await repo.alternar(id);
  publicar({charlas: await repo.listar()});
}
