import React from 'react';
import {Text,View} from 'react-native';
import {recargar,usePrograma} from './programaModel';
import {Lista,Opcion,s} from './componentes';

export function Catalogo({abrir,dia,elegirDia,tema,elegirTema}:{
  abrir:(id:string)=>void; dia:number; elegirDia:(dia:number)=>void;
  tema:string; elegirTema:(tema:string)=>void;
}) {
  const {charlas,cargando,descargado} = usePrograma();
  const filtradas = charlas.filter(f=>(!dia || f.day===dia) && (tema==='Todos' || f.track===tema));
  return <View>
    <View style={s.fila}>{['Ambos días','Día 1','Día 2'].map((t,i)=>
      <Opcion key={t} texto={t} activa={dia===i} accion={()=>elegirDia(i)}/>)}</View>
    <View style={s.fila}>{['Todos','Android','Datos','Calidad'].map(t=>
      <Opcion key={t} texto={t} activa={tema===t} accion={()=>elegirTema(t)}/>)}</View>
    <Opcion texto="Actualizar" accion={()=>void recargar()}/>
    {cargando && <Text>Consultando programa…</Text>}
    {!descargado && !cargando && <Opcion texto="Reintentar" accion={()=>void recargar()}/>}
    {descargado && charlas.length===0 && <Text>sin charlas programadas</Text>}
    {descargado && charlas.length>0 && filtradas.length===0 && <Text>No hay charlas para estos filtros.</Text>}
    <Lista fichas={filtradas} abrir={abrir}/>
  </View>;
}
