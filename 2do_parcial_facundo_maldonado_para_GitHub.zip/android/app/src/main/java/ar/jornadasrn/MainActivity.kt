package ar.jornadasrn

import android.os.Bundle
import com.facebook.react.ReactActivity
import com.facebook.react.ReactActivityDelegate
import com.facebook.react.defaults.DefaultReactActivityDelegate
import java.util.UUID

class MainActivity : ReactActivity() {
    private lateinit var sessionKey: String
    private var restaurada = false

    override fun onCreate(savedInstanceState: Bundle?) {
        restaurada = savedInstanceState != null
        sessionKey = savedInstanceState?.getString("sessionKey") ?: UUID.randomUUID().toString()
        super.onCreate(savedInstanceState)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putString("sessionKey", sessionKey)
        super.onSaveInstanceState(outState)
    }

    override fun getMainComponentName() = "JornadasRN"

    override fun createReactActivityDelegate(): ReactActivityDelegate =
        object : DefaultReactActivityDelegate(this, mainComponentName, false) {
            override fun getLaunchOptions() = Bundle().apply {
                putString("taskKey", sessionKey)
                putBoolean("offlineStart", !restaurada && !intent.getBooleanExtra("servicio_disponible", true))
            }
        }
}
