import {api} from '../lab/servicio';
import {alternar, Ficha, guardar, listar} from './archivo';

export const agendaRepository = {
  listar,
  alternar,
  async sincronizar() {
    const respuesta = await api.get<Ficha[]>('/programa');
    if (!Array.isArray(respuesta.data) || !respuesta.data.every(f =>
      f && typeof f.id === 'string' && typeof f.title === 'string' &&
      typeof f.day === 'number' && typeof f.track === 'string')) {
      throw new Error('El servicio devolvió un programa inválido');
    }
    await guardar(respuesta.data);
  },
};
